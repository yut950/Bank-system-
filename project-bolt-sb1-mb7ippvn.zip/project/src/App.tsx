import { Route, Switch } from 'wouter';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import NetworkPage from './pages/Network';
import ThreatsPage from './pages/Threats';
import LogsPage from './pages/Logs';
import SettingsPage from './pages/Settings';

export default function App() {
  return (
    <div className="flex h-screen bg-[#020617] text-slate-200 overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto p-8">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/network" component={NetworkPage} />
          <Route path="/threats" component={ThreatsPage} />
          <Route path="/logs" component={LogsPage} />
          <Route path="/settings" component={SettingsPage} />
        </Switch>
      </main>
    </div>
  );
}
