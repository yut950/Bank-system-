import { Shield, Lock, Key, Eye, RefreshCw } from 'lucide-react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const securityMetrics = [
  { name: 'Firewall', status: 'Active', score: 98, lastUpdate: '5 min ago' },
  { name: 'Antivirus', status: 'Active', score: 95, lastUpdate: '10 min ago' },
  { name: 'Intrusion Detection', status: 'Active', score: 92, lastUpdate: '2 min ago' },
  { name: 'Access Control', status: 'Active', score: 97, lastUpdate: '1 min ago' },
];

export function Security() {
  const data = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Security Score',
        data: [95, 96, 94, 97, 98, 96, 98],
        backgroundColor: 'rgba(6, 182, 212, 0.8)',
        borderColor: 'rgb(6, 182, 212)',
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        titleColor: '#ffffff',
        bodyColor: '#cbd5e1',
        borderColor: 'rgba(6, 182, 212, 0.5)',
        borderWidth: 1,
        padding: 12,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        grid: {
          color: 'rgba(148, 163, 184, 0.1)',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
      x: {
        grid: {
          color: 'rgba(148, 163, 184, 0.1)',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
    },
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Security Posture</h2>
        <p className="text-slate-400">Monitor and manage your security infrastructure</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-cyan-400" />
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">Overall Score</h3>
          <p className="text-white text-3xl font-bold">98.2%</p>
        </div>

        <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <Lock className="w-6 h-6 text-green-400" />
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">Encrypted Assets</h3>
          <p className="text-white text-3xl font-bold">100%</p>
        </div>

        <div className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Key className="w-6 h-6 text-blue-400" />
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">Active Sessions</h3>
          <p className="text-white text-3xl font-bold">127</p>
        </div>

        <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
              <Eye className="w-6 h-6 text-amber-400" />
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">Monitored Endpoints</h3>
          <p className="text-white text-3xl font-bold">342</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h3 className="text-white text-lg font-semibold mb-6">Weekly Security Score</h3>
          <div className="h-80">
            <Bar data={data} options={options} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-white text-lg font-semibold">Security Components</h3>
            <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
              <RefreshCw className="w-4 h-4 text-slate-400" />
            </button>
          </div>
          <div className="space-y-4">
            {securityMetrics.map((metric, index) => (
              <div key={index} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-white font-medium">{metric.name}</h4>
                    <p className="text-slate-400 text-sm">{metric.lastUpdate}</p>
                  </div>
                  <span className="px-3 py-1 bg-green-500/10 text-green-400 rounded-full text-xs border border-green-500/20">
                    {metric.status}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-slate-700 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all"
                      style={{ width: `${metric.score}%` }}
                    />
                  </div>
                  <span className="text-white font-medium text-sm">{metric.score}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
