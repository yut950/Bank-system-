import Header from '../components/Header';
import StatCard from '../components/StatCard';
import { AlertTriangle, Network, CheckCircle, Zap } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

export default function Dashboard() {
  const chartData = {
    labels: ['10am', '11am', '12pm', '01pm', '02pm', '03pm'],
    datasets: [{
      label: 'Security Threats',
      data: [12, 19, 3, 5, 2, 3],
      borderColor: '#22d3ee',
      backgroundColor: 'rgba(34, 211, 238, 0.1)',
      fill: true,
      tension: 0.4
    }]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: '#cbd5e1',
        }
      }
    },
    scales: {
      y: {
        ticks: {
          color: '#94a3b8'
        },
        grid: {
          color: 'rgba(148, 163, 184, 0.1)'
        }
      },
      x: {
        ticks: {
          color: '#94a3b8'
        },
        grid: {
          color: 'rgba(148, 163, 184, 0.1)'
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      <Header title="مركز الأمن السيبراني" />
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="التهديدات النشطة" value="14" icon={<AlertTriangle />} type="danger" />
        <StatCard title="الأجهزة المتصلة" value="1,240" icon={<Network />} type="success" />
        <StatCard title="جدار الحماية" value="نشط" icon={<CheckCircle />} type="success" />
        <StatCard title="استخدام المعالج" value="24%" icon={<Zap />} type="warning" />
      </div>
      <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-800">
        <h3 className="mb-4 font-bold text-cyan-400">تحليل التهديدات</h3>
        <div className="h-80">
          <Line data={chartData} options={chartOptions} />
        </div>
      </div>
    </div>
  );
}
