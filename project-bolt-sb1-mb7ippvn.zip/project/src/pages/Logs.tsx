import Header from '../components/Header';

export default function LogsPage() {
  const logs = [
    { time: '14:20:05', event: 'محاولة دخول فاشلة', ip: '185.2.x.x', severity: 'High' },
    { time: '14:18:12', event: 'تحديث الجدار الناري', ip: 'System', severity: 'Info' },
    { time: '14:15:30', event: 'اتصال VPN جديد', ip: '172.16.x.x', severity: 'Medium' },
    { time: '14:12:45', event: 'فحص أمني مكتمل', ip: 'System', severity: 'Info' },
    { time: '14:10:22', event: 'تحديث قاعدة بيانات التوقيعات', ip: 'System', severity: 'Info' },
  ];

  const getSeverityColor = (severity: string) => {
    switch(severity) {
      case 'High': return 'bg-red-500/20 text-red-400';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'Info': return 'bg-blue-500/20 text-blue-400';
      default: return 'bg-slate-500/20 text-slate-400';
    }
  };

  return (
    <div className="space-y-6">
      <Header title="سجلات النظام" />
      <div className="space-y-2">
        {logs.map((log, i) => (
          <div key={i} className="bg-slate-900 border border-slate-800 p-4 rounded-lg hover:border-slate-700 transition-colors">
            <div className="flex justify-between items-start">
              <div className="flex gap-4 flex-1">
                <span className="text-cyan-500 font-mono text-sm whitespace-nowrap">{log.time}</span>
                <span className="text-white flex-1">{log.event}</span>
              </div>
              <div className="flex gap-3 items-center">
                <span className="text-slate-400 text-sm font-mono">{log.ip}</span>
                <span className={`px-3 py-1 rounded text-xs whitespace-nowrap ${getSeverityColor(log.severity)}`}>
                  {log.severity}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
