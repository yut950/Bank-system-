import Header from '../components/Header';
import { Save, Bell, Lock, User, Zap } from 'lucide-react';
import { useState } from 'react';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    notifications: true,
    autoBlock: true,
    emailAlerts: true,
    darkMode: true,
  });

  return (
    <div className="space-y-6">
      <Header title="الإعدادات" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <User className="text-cyan-400" size={24} />
              <h3 className="text-lg font-bold text-white">بيانات المستخدم</h3>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-slate-400 text-sm mb-2">اسم المستخدم</label>
                <input
                  type="text"
                  defaultValue="محمد أحمد"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-slate-400 text-sm mb-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  defaultValue="admin@cybershield.local"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="text-cyan-400" size={24} />
              <h3 className="text-lg font-bold text-white">الإشعارات</h3>
            </div>
            <div className="space-y-4">
              <label className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg cursor-pointer hover:bg-slate-800 transition-colors">
                <span className="text-white">تفعيل الإشعارات</span>
                <input
                  type="checkbox"
                  checked={settings.notifications}
                  onChange={(e) => setSettings({...settings, notifications: e.target.checked})}
                  className="w-5 h-5 accent-cyan-500"
                />
              </label>
              <label className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg cursor-pointer hover:bg-slate-800 transition-colors">
                <span className="text-white">تنبيهات البريد الإلكتروني</span>
                <input
                  type="checkbox"
                  checked={settings.emailAlerts}
                  onChange={(e) => setSettings({...settings, emailAlerts: e.target.checked})}
                  className="w-5 h-5 accent-cyan-500"
                />
              </label>
              <label className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg cursor-pointer hover:bg-slate-800 transition-colors">
                <span className="text-white">حجب التهديدات تلقائياً</span>
                <input
                  type="checkbox"
                  checked={settings.autoBlock}
                  onChange={(e) => setSettings({...settings, autoBlock: e.target.checked})}
                  className="w-5 h-5 accent-cyan-500"
                />
              </label>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Zap className="text-cyan-400" size={24} />
              <h3 className="text-lg font-bold text-white">المتقدمة</h3>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-slate-400 text-sm mb-2">حد التنبيه</label>
                <select className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500">
                  <option>عالي (تهديدات حرجة فقط)</option>
                  <option>متوسط (تهديدات عالية وأعلى)</option>
                  <option>منخفض (جميع التهديدات)</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-400 text-sm mb-2">فترة انتظار الجلسة (دقائق)</label>
                <input
                  type="number"
                  defaultValue="30"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Lock className="text-cyan-400" size={24} />
              <h3 className="text-lg font-bold text-white">الأمان</h3>
            </div>
            <div className="space-y-3">
              <button className="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white rounded-lg px-4 py-3 transition-colors text-sm font-medium">
                تغيير كلمة المرور
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white rounded-lg px-4 py-3 transition-colors text-sm font-medium">
                المصادقة الثنائية
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white rounded-lg px-4 py-3 transition-colors text-sm font-medium">
                مفاتيح API
              </button>
            </div>
          </div>

          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-xl p-6">
            <h4 className="text-white font-bold mb-2">معلومات النظام</h4>
            <div className="space-y-2 text-sm">
              <p className="text-slate-400"><span className="text-slate-300">الإصدار:</span> 2.1.0</p>
              <p className="text-slate-400"><span className="text-slate-300">الحالة:</span> <span className="text-green-400">متاح</span></p>
              <p className="text-slate-400"><span className="text-slate-300">آخر تحديث:</span> 2024-12-25</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button className="flex items-center gap-2 px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors font-medium">
          <Save size={18} />
          حفظ التغييرات
        </button>
      </div>
    </div>
  );
}
