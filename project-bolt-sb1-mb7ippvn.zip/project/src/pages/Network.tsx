import Header from '../components/Header';

export default function NetworkPage() {
  const devices = [
    { name: 'خادم رئيسي', ip: '192.168.1.1', status: 'متصل', type: 'Server' },
    { name: 'بوابة الأمان', ip: '192.168.1.5', status: 'متصل', type: 'Gateway' },
    { name: 'محطة الإدارة', ip: '192.168.1.12', status: 'غير متصل', type: 'PC' },
  ];

  return (
    <div className="space-y-6">
      <Header title="مراقبة الشبكة" />
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
          <table className="w-full text-right">
            <thead className="bg-slate-800/50 text-slate-400">
              <tr>
                <th className="p-4">النوع</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">عنوان IP</th>
                <th className="p-4">اسم الجهاز</th>
              </tr>
            </thead>
            <tbody>
              {devices.map((device, i) => (
                <tr key={i} className="border-t border-slate-800 hover:bg-slate-800/30">
                  <td className="p-4 text-slate-400">{device.type}</td>
                  <td className="p-4">
                    <span className={device.status === 'متصل' ? 'text-green-400' : 'text-red-400'}>
                      {device.status}
                    </span>
                  </td>
                  <td className="p-4 text-slate-400 font-mono">{device.ip}</td>
                  <td className="p-4 font-bold text-white">{device.name}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
