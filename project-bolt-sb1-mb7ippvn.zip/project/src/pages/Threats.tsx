import Header from '../components/Header';
import { Shield, AlertTriangle, Zap } from 'lucide-react';

export default function ThreatsPage() {
  const threats = [
    { id: 1, type: 'محاولة اختراق', source: '185.220.x.x', severity: 'عالية', time: '14:32:15', blocked: true },
    { id: 2, type: 'محاولة DDoS', source: '203.0.x.x', severity: 'حرجة', time: '14:28:42', blocked: true },
    { id: 3, type: 'فحص الأنفاق', source: '192.168.x.x', severity: 'منخفضة', time: '14:15:30', blocked: false },
    { id: 4, type: 'هجوم SQL', source: '10.0.x.x', severity: 'عالية', time: '14:05:18', blocked: true },
  ];

  const getSeverityColor = (severity: string) => {
    switch(severity) {
      case 'حرجة': return 'bg-red-500/20 text-red-400';
      case 'عالية': return 'bg-orange-500/20 text-orange-400';
      case 'منخفضة': return 'bg-yellow-500/20 text-yellow-400';
      default: return 'bg-blue-500/20 text-blue-400';
    }
  };

  return (
    <div className="space-y-6">
      <Header title="إدارة التهديدات" />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900/50 border border-red-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-2">التهديدات المكتشفة</p>
              <p className="text-3xl font-bold text-red-400">23</p>
            </div>
            <AlertTriangle className="text-red-400 opacity-50" size={40} />
          </div>
        </div>

        <div className="bg-slate-900/50 border border-green-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-2">التهديدات المحجوبة</p>
              <p className="text-3xl font-bold text-green-400">21</p>
            </div>
            <Shield className="text-green-400 opacity-50" size={40} />
          </div>
        </div>

        <div className="bg-slate-900/50 border border-cyan-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-2">معدل الحماية</p>
              <p className="text-3xl font-bold text-cyan-400">91.3%</p>
            </div>
            <Zap className="text-cyan-400 opacity-50" size={40} />
          </div>
        </div>
      </div>

      <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800">
          <h3 className="text-white font-bold text-lg">التهديدات الأخيرة</h3>
        </div>
        <table className="w-full text-right">
          <thead className="bg-slate-800/50 text-slate-400">
            <tr>
              <th className="p-4">الحالة</th>
              <th className="p-4">الوقت</th>
              <th className="p-4">مستوى الخطورة</th>
              <th className="p-4">المصدر</th>
              <th className="p-4">نوع التهديد</th>
            </tr>
          </thead>
          <tbody>
            {threats.map((threat) => (
              <tr key={threat.id} className="border-t border-slate-800 hover:bg-slate-800/30">
                <td className="p-4">
                  <span className={`px-3 py-1 rounded text-xs ${threat.blocked ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    {threat.blocked ? 'محجوب' : 'نشط'}
                  </span>
                </td>
                <td className="p-4 text-slate-400 font-mono text-sm">{threat.time}</td>
                <td className="p-4">
                  <span className={`px-3 py-1 rounded text-xs ${getSeverityColor(threat.severity)}`}>
                    {threat.severity}
                  </span>
                </td>
                <td className="p-4 text-slate-400 font-mono text-sm">{threat.source}</td>
                <td className="p-4 text-white font-medium">{threat.type}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
