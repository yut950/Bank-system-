import { Bell, CheckCircle, XCircle, AlertTriangle, Info } from 'lucide-react';

const alertsList = [
  {
    id: '1',
    type: 'critical',
    title: 'Multiple Failed Login Attempts',
    description: 'Detected 127 failed authentication attempts from IP 203.45.67.89',
    timestamp: '2024-12-25 14:32:15',
    acknowledged: false,
  },
  {
    id: '2',
    type: 'success',
    title: 'Threat Successfully Blocked',
    description: 'Malicious payload intercepted and neutralized by firewall',
    timestamp: '2024-12-25 13:45:22',
    acknowledged: true,
  },
  {
    id: '3',
    type: 'warning',
    title: 'Unusual Network Traffic Pattern',
    description: 'Spike in outbound traffic detected on port 8080',
    timestamp: '2024-12-25 12:18:45',
    acknowledged: false,
  },
  {
    id: '4',
    type: 'info',
    title: 'Security Update Available',
    description: 'New security patches available for critical systems',
    timestamp: '2024-12-25 11:30:00',
    acknowledged: false,
  },
  {
    id: '5',
    type: 'critical',
    title: 'Ransomware Detected',
    description: 'Suspicious file encryption activity on server-prod-03',
    timestamp: '2024-12-25 10:05:33',
    acknowledged: true,
  },
];

const alertConfig = {
  critical: {
    icon: XCircle,
    iconColor: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
  },
  warning: {
    icon: AlertTriangle,
    iconColor: 'text-amber-400',
    bgColor: 'bg-amber-500/10',
    borderColor: 'border-amber-500/30',
  },
  info: {
    icon: Info,
    iconColor: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
  },
  success: {
    icon: CheckCircle,
    iconColor: 'text-green-400',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/30',
  },
};

export function Alerts() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Security Alerts</h2>
          <p className="text-slate-400">Manage and respond to security events</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors">
          <CheckCircle className="w-4 h-4" />
          <span>Acknowledge All</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-red-500/10 rounded-lg flex items-center justify-center">
              <XCircle className="w-5 h-5 text-red-400" />
            </div>
            <span className="text-2xl font-bold text-white">8</span>
          </div>
          <p className="text-slate-400 text-sm">Critical</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-2xl font-bold text-white">15</span>
          </div>
          <p className="text-slate-400 text-sm">Warning</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
              <Info className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-2xl font-bold text-white">23</span>
          </div>
          <p className="text-slate-400 text-sm">Info</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-400" />
            </div>
            <span className="text-2xl font-bold text-white">156</span>
          </div>
          <p className="text-slate-400 text-sm">Resolved</p>
        </div>
      </div>

      <div className="space-y-4">
        {alertsList.map((alert) => {
          const config = alertConfig[alert.type as keyof typeof alertConfig];
          const Icon = config.icon;

          return (
            <div
              key={alert.id}
              className={`bg-slate-900 border rounded-xl p-6 ${config.borderColor} ${alert.acknowledged ? 'opacity-60' : ''}`}
            >
              <div className="flex items-start gap-4">
                <div className={`${config.bgColor} p-3 rounded-lg`}>
                  <Icon className={`w-6 h-6 ${config.iconColor}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-white text-lg font-semibold">{alert.title}</h3>
                    {alert.acknowledged && (
                      <span className="px-3 py-1 bg-slate-800 text-slate-400 text-xs rounded-full">
                        Acknowledged
                      </span>
                    )}
                  </div>
                  <p className="text-slate-400 mb-3">{alert.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-sm">{alert.timestamp}</span>
                    {!alert.acknowledged && (
                      <button className="px-4 py-2 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg hover:bg-cyan-500/20 transition-colors text-sm">
                        Acknowledge
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
