interface HeaderProps {
  title: string;
}

export default function Header({ title }: HeaderProps) {
  return (
    <div className="mb-6">
      <h2 className="text-3xl font-bold text-white">{title}</h2>
      <p className="text-slate-400 mt-2">آخر تحديث: الآن</p>
    </div>
  );
}
