import { AlertTriangle, Shield, Info, XCircle } from 'lucide-react';
import { cn } from '../lib/utils';

interface Alert {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'blocked';
  message: string;
  time: string;
  source: string;
}

const alerts: Alert[] = [
  {
    id: '1',
    type: 'critical',
    message: 'Multiple failed login attempts detected',
    time: '2 minutes ago',
    source: '192.168.1.105',
  },
  {
    id: '2',
    type: 'blocked',
    message: 'Malicious payload blocked at firewall',
    time: '15 minutes ago',
    source: '203.45.67.89',
  },
  {
    id: '3',
    type: 'warning',
    message: 'Unusual network traffic pattern',
    time: '1 hour ago',
    source: '10.0.0.45',
  },
  {
    id: '4',
    type: 'info',
    message: 'Security scan completed successfully',
    time: '2 hours ago',
    source: 'System',
  },
  {
    id: '5',
    type: 'blocked',
    message: 'SQL injection attempt prevented',
    time: '3 hours ago',
    source: '198.51.100.42',
  },
];

const alertConfig = {
  critical: {
    icon: XCircle,
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
  },
  warning: {
    icon: AlertTriangle,
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/20',
  },
  info: {
    icon: Info,
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/20',
  },
  blocked: {
    icon: Shield,
    color: 'text-green-400',
    bg: 'bg-green-500/10',
    border: 'border-green-500/20',
  },
};

export function RecentAlerts() {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
      <h3 className="text-white text-lg font-semibold mb-6">Recent Alerts</h3>
      <div className="space-y-3">
        {alerts.map((alert) => {
          const config = alertConfig[alert.type];
          const Icon = config.icon;

          return (
            <div
              key={alert.id}
              className={cn(
                'p-4 rounded-lg border flex items-start gap-4 transition-all hover:scale-[1.02]',
                config.bg,
                config.border
              )}
            >
              <div className={cn('mt-0.5', config.color)}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium mb-1">{alert.message}</p>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span>{alert.time}</span>
                  <span>•</span>
                  <span className="truncate">{alert.source}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
