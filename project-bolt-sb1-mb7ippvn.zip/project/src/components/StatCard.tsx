import { ReactNode } from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  type: 'danger' | 'success' | 'warning' | 'info';
}

const typeStyles = {
  danger: 'bg-red-500/10 border-red-500/30 text-red-400',
  success: 'bg-green-500/10 border-green-500/30 text-green-400',
  warning: 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400',
  info: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
};

export default function StatCard({ title, value, icon, type }: StatCardProps) {
  return (
    <div className={`bg-slate-900/50 border rounded-xl p-6 ${typeStyles[type]}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-slate-400 text-sm mb-2">{title}</p>
          <p className="text-3xl font-bold text-white">{value}</p>
        </div>
        <div className="text-3xl opacity-50">{icon}</div>
      </div>
    </div>
  );
}
