import { useLocation } from 'wouter';
import { BarChart3, Network, Shield, FileText, Settings, ShieldAlert } from 'lucide-react';

export default function Sidebar() {
  const [location, setLocation] = useLocation();

  const menuItems = [
    { label: 'لوحة التحكم', icon: <BarChart3 size={20} />, path: '/' },
    { label: 'الشبكة', icon: <Network size={20} />, path: '/network' },
    { label: 'التهديدات', icon: <ShieldAlert size={20} />, path: '/threats' },
    { label: 'السجلات', icon: <FileText size={20} />, path: '/logs' },
    { label: 'الإعدادات', icon: <Settings size={20} />, path: '/settings' },
  ];

  return (
    <aside className="w-64 bg-[#0f172a] border-r border-slate-800 flex flex-col h-full">
      <div className="p-6 flex items-center gap-3 border-b border-slate-800">
        <div className="bg-cyan-500 p-2 rounded-lg text-white">
          <Shield size={24} />
        </div>
        <h1 className="text-xl font-bold text-white tracking-wider">CyberShield</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.path}
            onClick={() => setLocation(item.path)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              location === item.path
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {item.icon}
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
}
